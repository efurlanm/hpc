<LI><A NAME="tex2html75" HREF="HTMLNotesnode287.html#18092">Execution of EP from NAS Benchmarks Suite on a 2-Processor
SPARCcenter 1000 (sun4d)</A>
<LI><A NAME="tex2html76" HREF="HTMLNotesnode287.html#18107">Execution of PDE1 over 1, 2, 4, 8 and 16 processors on a
Sun SPARCCentre 2000 and an SGI Power Challenge XL. </A>
<LI><A NAME="tex2html77" HREF="HTMLNotesnode287.html#18126">Execution of FFT1 over 1, 2, 4, 8 and 16 processors on a
SPARCCentre 2000 and Power Challenge XL.</A>
